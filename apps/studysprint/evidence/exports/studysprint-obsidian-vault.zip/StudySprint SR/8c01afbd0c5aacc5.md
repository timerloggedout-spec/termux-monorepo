---
studysprint: sr-card/v1
card_id: 8c01afbd0c5aacc5
scheduler: fsrs
due: 
interval_days: 
tags: ["cell structure"]
---

#flashcards

What does the cell membrane do?
?
Controls what enters and leaves the cell.
