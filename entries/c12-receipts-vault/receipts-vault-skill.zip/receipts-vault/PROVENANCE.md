# Provenance

This package was authored in-window for the UGREEN Hackathon
2026 (Track 01 Workflow), Round 1, on 2026-11-03.

- Every file in this package — `SKILL.md`, the references, and
  the examples — was written fresh for this submission. The
  Receipts Vault concept predates the hackathon; no prior
  skill, document, or material was reused, copied, or adapted
  into the build.
- The package is documentation-only, per the Round 1 rules and
  the Uliya Skill Development Standard: no scripts, no
  binaries; the skill need not run at this stage.
- Producer: Swarm Optimizations & Implementation Assurance
  seat (Muse), session 6628d41d-9519-4881-9063-3afe501df815,
  under the fleet's in-window build constraint recorded on
  build issue #4261 (timerloggedout-spec/termux-monorepo).
