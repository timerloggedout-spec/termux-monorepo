---
name: receipts-vault
description: Organize, index, and retrieve every receipt stored on the NAS. Use when the user drops receipt photos, scans, or PDFs into the inbox folder, asks what they paid for something, needs proof of purchase, wants a monthly or tax-time expense bundle, or asks which warranties are about to lapse. Files each receipt once, immutably, into a year/month/category vault with an extracted record (vendor, date, total, currency, category), deduplicates by content hash, and answers retrieval questions from the index — never from memory.
license: MIT
---

# Receipts Vault

A personal NAS skill that turns a pile of receipt photos, scans,
and emailed PDFs into a vault you can actually interrogate:
every receipt filed once, findable in seconds, with its facts
extracted and its original never modified.

## The vault contract

Three promises, in priority order:

1. **Originals are immutable.** An ingested file is copied into
   the vault and never edited, renamed in place, or deleted by
   the skill. Corrections live in the record, not the file.
2. **Every fact carries its source.** Each extracted field is
   traceable to the receipt image it came from; the record
   stores the file's SHA-256 so any later copy can be verified
   against the original.
3. **Nothing files silently.** Low-confidence extractions and
   every destructive-adjacent action (none by default) stop for
   user confirmation. A receipt the skill cannot read is filed
   as `unread/` with a note, never guessed into a category.

## Layout

```
/ReceiptsVault
  inbox/                 drop zone — the skill watches this
  vault/<YYYY>/<MM>/<category>/   filed originals
  index/receipts.jsonl   one JSON record per receipt
  exports/               generated bundles (monthly, tax, warranty)
  unread/                could-not-read originals + notes
```

Naming inside the vault:
`<date>_<vendor-slug>_<total><currency>_<hash8>.<ext>`
— sortable, human-readable, and unique by construction.
Full taxonomy: `references/vault-layout.md`.

## Workflow

### 1. Intake
New files appearing in `inbox/` (photo, scan, or PDF) are the
trigger. For each: compute SHA-256, check the index for the
same hash — a duplicate is logged and left in place, never
filed twice (see `references/dedupe-and-integrity.md`).

### 2. Extract
Read the receipt and produce a record per
`references/extraction-schema.md`:

- vendor, date, total, currency, category
- line items when legible; payment method's last four digits
  when printed
- warranty months, when the receipt or the user states them
- a confidence per field: `read`, `inferred`, or `unread`

Currency and totals are copied, never converted or rounded —
a receipt is evidence, and evidence is quoted, not improved.

### 3. Confirm
If any of {vendor, date, total} is `inferred` or `unread`,
present the record and the image side by side and ask the user
to confirm or correct before filing. Fully-`read` records file
without interrupting. Confirmations and corrections are stored
on the record (`confirmed_by: user`, with the prior value kept)
— the audit trail is part of the vault.

### 4. File
Copy the original to its vault path, append the record to the
index, and remove the inbox copy only after the vault copy's
hash verifies equal. If verification fails, keep both and
report — never lose the only copy to a tidy-up step.

### 5. Retrieve
Answer questions from the index, citing the record and its
vault path:

- "What did I pay for the washing machine?" → the record, the
  total, the date, and the file to open for proof.
- "Show me every receipt from this spring over €100." →
  filtered records, newest first, with paths.
- "Do I still have the receipt for the laptop?" → yes/no with
  the record, or an honest "not in the vault" — the skill never
  invents a record to be helpful.

### 6. Automate
Scheduled, from the index only (`references/workflows.md`):

- **Monthly close**: a bundle (CSV + copies) of the month's
  receipts by category, totals per category, anomalies flagged
  (a total that deviates from the vendor's usual range).
- **Warranty watch**: purchase date + warranty months →
  a reminder 30 days before lapse, with the receipt path
  attached so the proof is one tap away at claim time.
- **Tax-time bundle**: a year export grouped by the user's
  deductible categories, records + originals, ready to hand
  to an accountant.

## Safety and privacy

Receipts are personal financial data. The skill runs locally
on the NAS, sends nothing off-device, and keeps the PII rules
in `references/safety-and-privacy.md`: share a bundle only to a
destination the user names, redact payment digits in exports
by default, and treat "send my receipts to…" as an action that
always asks first.

## Failure behavior

- Unreadable image → `unread/` + a note asking for a clearer
  photo; the monthly close reports the unread count so nothing
  rots silently.
- Conflicting duplicates (same vendor/date/total, different
  hash) → both filed, both records cross-linked as
  `possible_duplicate_of`; the user decides at retrieval time.
- Index missing or corrupt → rebuild it from the vault
  filenames + a re-extraction pass; originals are the truth,
  the index is a cache with good manners.

## Examples

Annotated sample records and a worked monthly close live in
`examples/example-records.md`.
