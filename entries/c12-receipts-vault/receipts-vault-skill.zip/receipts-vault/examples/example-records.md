# Example records and a worked retrieval

Fictional data, shaped exactly like the real index
(`references/extraction-schema.md`).

## Two records

```json
{"id": "rcpt_9f2ac41b", "vendor": "MediaStore", "date": "2026-01-05", "total": 899.00, "currency": "EUR", "category": "electronics", "warranty_months": 24, "payment_last4": "4417", "source": "scan", "vault_path": "vault/2026/01/electronics/2026-01-05_mediastore_899.00EUR_9f2ac41b.pdf"}
{"id": "rcpt_51bd07e2", "vendor": "City Pharmacy", "date": "2026-02-11", "total": 23.65, "currency": "EUR", "category": "health", "warranty_months": null, "payment_last4": null, "source": "photo", "vault_path": "vault/2026/02/health/2026-02-11_city-pharmacy_23.65EUR_51bd07e2.jpg"}
```

## A retrieval

User: "The laptop from January — do I still have warranty,
and where's the receipt?"

Skill, from the index: the MediaStore record — bought
2026-01-05, 24 months → covered until 2028-01-05; the proof is
at the record's vault path. The answer cites the record id and
path; nothing is recalled from conversation memory, so a wrong
answer can be checked against the index line itself.

## A confirm-gate moment

A photo arrives where the total reads either 23.65 or 28.65.
Total is `inferred`, so nothing files yet. The skill shows the
image and its best reading and asks; the user picks 23.65; the
record files with `confirmed_by: user` and the rejected
reading preserved in `corrections`. The next monthly close
counts one user-confirmed filing — the vault knows which of its
facts a human has actually vouched for.
