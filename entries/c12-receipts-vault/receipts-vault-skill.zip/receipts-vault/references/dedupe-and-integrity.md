# Dedupe and integrity

## Identity is the hash

A receipt IS its file's SHA-256. At intake the hash is checked
against the index before anything else happens:

- **Same hash already filed** → the inbox copy is a duplicate.
  It is logged (`duplicate_of: rcpt_…`) and, after the user is
  shown it once, removed from the inbox. The vault copy is
  untouched.
- **Same hash, different suggested category** → still the same
  receipt. The filed record wins; the disagreement is noted.

## Near-duplicates are not duplicates

The same purchase photographed twice produces two different
files (different bytes, different hash). Signals — same vendor,
same date, same total, filed within days — mark both records
`possible_duplicate_of` each other. Both stay in the vault:
deleting a "probable" duplicate is how real proof of purchase
gets destroyed, and storage is cheaper than regret.

## Integrity checks

- **Verify after copy**: a filing completes only when the vault
  copy's hash equals the inbox original's hash. The inbox copy
  is removed last, never first.
- **Monthly self-audit** (part of the monthly close): re-hash a
  rotating sample of vault files and compare with the index.
  Any mismatch is reported by name in the close summary —
  silent bit-rot is exactly what a vault exists to catch.
- **Index rebuild**: filenames carry date/vendor/total/hash8,
  so a lost index can be rebuilt from the vault tree plus a
  re-extraction pass. Originals are the source of truth; the
  index is a derived view.
