# Extraction schema

One JSON object per receipt, appended to `index/receipts.jsonl`.

```json
{
  "id": "rcpt_a1b2c3d4",
  "sha256": "<full hex of the original file>",
  "vault_path": "vault/2026/03/groceries/2026-03-14_boulangerie-marie_12.40EUR_a1b2c3d4.jpg",
  "vendor": "Boulangerie Marie",
  "vendor_confidence": "read",
  "date": "2026-03-14",
  "date_confidence": "read",
  "total": 12.40,
  "currency": "EUR",
  "total_confidence": "read",
  "category": "groceries",
  "items": [{"label": "pain au levain", "amount": 4.20}],
  "payment_last4": null,
  "warranty_months": null,
  "source": "photo",
  "confirmed_by": null,
  "corrections": [],
  "possible_duplicate_of": null,
  "filed_at": "2026-03-14T19:02:11+01:00"
}
```

## Field rules

- **Confidence** is per field, one of `read` (legible on the
  receipt), `inferred` (derived — e.g. currency from the
  vendor's country), `unread` (present but not legible).
  Filing without confirmation requires vendor, date, and total
  all `read`.
- **Totals are quoted, never computed.** If line items sum to
  something else, the printed total wins and the discrepancy is
  noted in `corrections` as a machine observation, not a fix.
- **Dates** are the purchase date printed on the receipt, in
  the receipt's own timezone when known; `filed_at` is filing
  time and never substitutes for it.
- **Corrections** keep the prior value: `{"field": "total",
  "was": 12.04, "now": 12.40, "by": "user", "at": "..."}`.
  The record is an audit trail, not a scratchpad.
- **Items** are optional and best-effort; a receipt with no
  legible items is still a complete record.
