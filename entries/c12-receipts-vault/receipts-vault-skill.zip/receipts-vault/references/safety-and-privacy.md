# Safety and privacy

Receipts reveal where you shop, what you eat, what you take
for your health, and when you travel. The vault treats them as
sensitive by default.

## Local only

Extraction, indexing, and automations run on the NAS. No
receipt image, record, or total leaves the device except in an
export the user explicitly requests, to a destination the user
names in that request.

## Sharing asks first, every time

"Send my receipts to my accountant" is an action, not a
conversation: the skill states exactly which records and files
would be shared, with whom, and waits for confirmation. A
previous yes never becomes a standing permission.

## Redaction is a view

Exports redact `payment_last4` and can blur card-adjacent
fields on request. Redaction applies to the export copy only —
the vault original and its record stay complete, because a
vault that quietly edits its evidence has stopped being one.

## Access

The vault inherits the NAS's own user permissions; the skill
adds no accounts, no sharing links, and no public folders. If
the NAS user can read the folder, they can read the receipts —
the skill says this plainly in setup rather than implying a
second lock it does not provide.
