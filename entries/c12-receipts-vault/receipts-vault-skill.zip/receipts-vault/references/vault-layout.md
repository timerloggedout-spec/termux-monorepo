# Vault layout and taxonomy

## Directories

| Path | Holds | Rules |
|---|---|---|
| `inbox/` | newly dropped receipt files | the only directory the user writes to; emptied by verified filing |
| `vault/<YYYY>/<MM>/<category>/` | filed originals | append-only; the skill never edits or deletes here |
| `index/receipts.jsonl` | one JSON record per receipt | append-only; rebuildable from the vault |
| `exports/` | generated bundles | regenerable at any time; safe to delete |
| `unread/` | originals the skill could not read | each with a `.note.md` naming what failed |

## Categories (v1, fixed list)

`groceries` · `household` · `electronics` · `appliances` ·
`clothing` · `health` · `transport` · `dining` · `travel` ·
`services` · `subscriptions` · `other`

A fixed list on purpose: category search is only useful if the
categories mean the same thing in March as in October. A vendor
learned once ("the bakery on Rue Cler is groceries") is stored
on the vendor map in the index header and reused, so the user
teaches each vendor at most once.

## File naming

`<date>_<vendor-slug>_<total><currency>_<hash8>.<ext>`

- `date` — purchase date, `YYYY-MM-DD`; unknown day → `YYYY-MM`
- `vendor-slug` — lowercase, spaces to `-`, punctuation dropped
- `total` — as printed, decimal point, no thousands separators
- `hash8` — first 8 hex chars of the file's SHA-256; guarantees
  uniqueness even when two receipts share date/vendor/total

Example: `2026-03-14_boulangerie-marie_12.40EUR_a1b2c3d4.jpg`
