# Automations (from the index only)

All three automations read only the index and the vault —
never the inbox — so a half-filed receipt never leaks into a
report.

## Monthly close

On the 1st, for the month just ended:

1. Bundle: copies of the month's originals + `summary.csv`
   (date, vendor, category, total, currency, vault path).
2. Totals per category, and a running year-to-date per
   category beside them.
3. Flags, not verdicts: totals that deviate strongly from the
   same vendor's trailing average, and the `unread/` count for
   the month.
4. Delivered as one folder in `exports/<YYYY-MM>_close/` and a
   short message: counts, totals, flags. Nothing is sent
   anywhere else.

## Warranty watch

For every record with `warranty_months`: lapse date = purchase
date + months. At 30 days before lapse, one reminder naming the
item, the vendor, the lapse date, and the vault path of the
receipt — the document a warranty claim actually needs,
attached at the moment it matters. Lapsed warranties are
reported once in the next monthly close, then never nagged
about again.

## Tax-time bundle

On request (or each January): for a chosen year, export the
user's deductible categories (marked in the index header, e.g.
`health`, `services`) as `exports/<YYYY>_tax/` — originals,
records, and a totals sheet. Payment last-fours are redacted
in the exported records by default (see
`safety-and-privacy.md`); the vault originals are never
redacted, because redaction is an export view, not an edit.
