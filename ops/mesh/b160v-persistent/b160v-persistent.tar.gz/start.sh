#!/data/data/com.termux/files/usr/bin/sh
# start.sh — launch the supervisor + tunnel loop detached (idempotent).
# Persistence on this device = a service under ~/bin/supervisor.sh (the
# owner's keep-alive loop: rish probe, then pgrep-guarded nohup starts).
# install.sh adds a b160v-tunnel stanza to supervisor.sh; this script
# makes sure supervisor itself is running, then starts the loop directly
# too (the loop is pidfile-guarded, so double starts are no-ops).
DIR="$HOME/b160v-persistent"
if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock >/dev/null 2>&1 || true
fi
pgrep sshd >/dev/null 2>&1 || sshd
if ! pgrep -f "bin/supervisor.sh" >/dev/null 2>&1; then
  nohup "$HOME/bin/supervisor.sh" >/dev/null 2>&1 &
  echo "b160v-persistent: supervisor started"
fi
setsid nohup sh "$HOME/bin/b160v-tunnel.sh" >/dev/null 2>&1 &
echo "b160v-persistent: start requested"
